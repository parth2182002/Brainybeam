# sqlboiler-sqlite3

## Configuration

```toml
# Absolute path is recommended since the location
# sqlite3 is being run can change.
# For example generation time and model test time.
[sqlite3]
dbname = "/path/to/file"
```
